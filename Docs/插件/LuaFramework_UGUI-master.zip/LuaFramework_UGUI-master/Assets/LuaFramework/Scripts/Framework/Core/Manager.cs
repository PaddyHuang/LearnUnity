﻿using UnityEngine;
using System.Collections;
using LuaFramework;

public class Manager : Base, IManager {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
