不同平台使用的编码器不同
==============================
luajit:     win, android using luajit2.0.4. 
luavm:	    macos using luac(for u5.x). 
luajit_ios: ios using luajit2.1beta

