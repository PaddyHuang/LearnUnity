# BaiduSpeechRecognitionTest
Learn how to use Baidu Speech Recognition API on Unity.
